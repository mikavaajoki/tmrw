<?php


namespace AgreableCatfishImporterPlugin\Exception;


/**
 * Class WrongDataFormatException
 *
 * @package AgreableCatfishImporterPlugin\Exception
 */
class WrongDataFormatException extends CatfishException {

}
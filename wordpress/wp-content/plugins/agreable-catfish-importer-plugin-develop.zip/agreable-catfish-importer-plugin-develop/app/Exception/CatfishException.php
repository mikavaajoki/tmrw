<?php


namespace AgreableCatfishImporterPlugin\Exception;


class CatfishException extends \Exception {

}
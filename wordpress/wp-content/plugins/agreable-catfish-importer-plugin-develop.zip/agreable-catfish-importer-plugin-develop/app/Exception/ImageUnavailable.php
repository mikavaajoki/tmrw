<?php


namespace AgreableCatfishImporterPlugin\Exception;


class ImageUnavailable extends CatfishException {

}
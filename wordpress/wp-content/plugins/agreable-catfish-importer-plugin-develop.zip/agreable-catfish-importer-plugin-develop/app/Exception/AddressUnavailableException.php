<?php


namespace AgreableCatfishImporterPlugin\Exception;


/**
 * Class AddressUnavailableException
 *
 * @package AgreableCatfishImporterPlugin\Exception
 */
class AddressUnavailableException extends CatfishException {

}